# SoftGroupTest
Answers to test tasks.
